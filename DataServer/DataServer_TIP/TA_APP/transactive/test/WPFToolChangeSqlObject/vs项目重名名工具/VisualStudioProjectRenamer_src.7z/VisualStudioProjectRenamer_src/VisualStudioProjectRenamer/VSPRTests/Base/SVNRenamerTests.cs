﻿using System;

namespace VSPRTests.Base
{
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using VSPRBase;

    [TestClass]
    public class SVNRenamerTests
    {
        [TestMethod]
        public void TestMethod1()
        {
            SVNRenamer svnRenamer = new SVNRenamer("", "", "", false);
            svnRenamer.Rename();
        }
    }
}