using System;

namespace VSPRBase
{
    using System.IO;

    public sealed class StandardRenamer : Renamer
    {
        /// <summary>
        /// Creates a new instance of Renamer class.
        /// </summary>
        /// <param name="solutionFilePath">The absolute path to the solution file</param>
        /// <param name="oldProjectName">The name of the old project</param>
        /// <param name="newProjectName">The name of the new project</param>
        public StandardRenamer(string solutionFilePath, string oldProjectName, string newProjectName)
        {
            // Check the parameters for valid values and set directories
            this.CheckParameter(solutionFilePath, oldProjectName, newProjectName);
            this.SetDirectories(solutionFilePath, oldProjectName, newProjectName);

            this.SolutionPath = solutionFilePath;
            this.OldProjectName = oldProjectName;
            this.NewProjectName = newProjectName;
        }

        /// <summary>
        /// Entry point. This method chain calls different other methods, that are responsible to make
        /// the necessary changes to files and folders in a chronological order.
        /// </summary>
        public override void Rename()
        {
            bool renameSuccessfull = true;
            try
            {
                this.ReplaceProjectReferencesInSolutionFile();
                this.RenameProjectFolder();
                this.RenameProjectFile();
                this.ReplaceOccurencesInProjectFile();
                this.ReplaceOccurencesInAssemblyInfo();
                this.ReplaceOccurencesInNameSpaces();
            }
            catch (Exception exception)
            {
                renameSuccessfull = false;
                Logger.Log(string.Format("{0}{1}:{2}{3}", DateTime.Now, Constants.Rename, Environment.NewLine, exception.Message));
                this.RollBack();
            }
            finally
            {
                this.InvokeRenameFinished(new RenameFinishedEventArgs(true, renameSuccessfull));
            }
        }

        protected override void RollBack()
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Renames the name of the old project file (*.csproj) to the new project name.
        /// </summary>
        protected override void RenameProjectFile()
        {
            string oldProjectFile = string.Format("{0}{1}{2}{3}", this.NewProjectDirectoryPath, "\\", this.OldProjectName, Constants.ProjectFileExtension);
            string newProjectFile = string.Format("{0}{1}{2}{3}", this.NewProjectDirectoryPath, "\\", this.NewProjectName, Constants.ProjectFileExtension);

            Guard.FileExists(oldProjectFile);
            try
            {
                File.Move(oldProjectFile, newProjectFile);
            }
            catch (Exception exception)
            {
                Logger.Log(string.Format("{0} {1}:{2}{3}", DateTime.Now, Constants.RenameProjectFile, Environment.NewLine, exception.Message));
                throw;
            }
        }

        /// <summary>
        /// Renames the name of the old project folder to the new project name.
        /// </summary>
        protected override void RenameProjectFolder()
        {
            try
            {
                Directory.Move(this.OldProjectDirectoryPath, this.NewProjectDirectoryPath);
            }
            catch (Exception exception)
            {
                Logger.Log(string.Format("{0} {1}:{2}{3}", DateTime.Now, Constants.RenameProjectFolder, Environment.NewLine, exception.Message));
                throw;
            }
        }
    }     
}