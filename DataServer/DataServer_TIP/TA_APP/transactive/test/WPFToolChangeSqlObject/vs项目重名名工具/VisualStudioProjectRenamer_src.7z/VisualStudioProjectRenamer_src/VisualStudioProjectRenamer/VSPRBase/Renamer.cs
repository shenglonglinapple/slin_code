using System;

namespace VSPRBase
{
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Text.RegularExpressions;

    public abstract class Renamer
    {
        protected Renamer()
        {
            this.Commands = new List<string>();
        }

        protected List<string> Commands { get; set; }

        /// <summary>
        /// The absolute path to the new (renamed) project directory.
        /// </summary>
        protected string NewProjectDirectoryPath { get; set; }

        /// <summary>
        /// The new project name.
        /// </summary>
        protected string NewProjectName { get; set; }

        /// <summary>
        /// The absolute path to the old project directory.
        /// </summary>
        protected string OldProjectDirectoryPath { get; set; }

        /// <summary>
        /// The old project name.
        /// </summary>
        protected string OldProjectName { get; set; }

        public int ProgressBarUpdateAmount { get; set; }

        /// <summary>
        /// The absolute path to the directory, in which the solution (file) is present.
        /// </summary>
        protected string SolutionDirectoryPath { get; set; }

        /// <summary>
        /// The absolute path to the solution file.
        /// </summary>
        protected string SolutionPath { get; set; }

        public event EventHandler<RenameFinishedEventArgs> RenameFinished;

        public event EventHandler<UpdateProgressBarEventArgs> UpdateProgressBar;

        public abstract void Rename();

        protected abstract void RenameProjectFile();

        protected abstract void RenameProjectFolder();

        protected abstract void RollBack();

        /// <summary>
        /// Check passed in parameters for validity.
        /// </summary>
        /// <param name="solutionFilePath">The absolute path to the solution file</param>
        /// <param name="oldProject">The name of the old project</param>
        /// <param name="newProject">The name of the new project</param>
        protected virtual void CheckParameter(string solutionFilePath, string oldProject, string newProject)
        {
            Guard.FileExists(solutionFilePath);
            Guard.IsNotNullOrEmpty(oldProject);
            Guard.IsNotNullOrEmpty(newProject);
        }

        protected virtual void InvokeRenameFinished(RenameFinishedEventArgs args)
        {
            EventHandler<RenameFinishedEventArgs> handler = this.RenameFinished;
            if (handler != null)
            {
                handler(this,args);
            }
        }

        protected virtual void InvokeUpdateProgressBar(UpdateProgressBarEventArgs args)
        {
            EventHandler<UpdateProgressBarEventArgs> handler = this.UpdateProgressBar;
            if (handler != null)
            {
                handler(this, args);
            }
        }

        /// <summary>
        /// Uses a regex to replace occurences in files.
        /// </summary>
        /// <param name="file">The path to the file</param>
        /// <param name="searchFor">The term to look for in the file</param>
        /// <param name="replaceWith">The term to replace with</param>
        protected virtual void Replace(string file, string searchFor, string replaceWith)
        {
            string fileContent;

            // Read file
            using (StreamReader reader = new StreamReader(file))
            {
                fileContent = reader.ReadToEnd();
            }

            // Use regular expressions to search and replace text
            fileContent = Regex.Replace(fileContent, searchFor, replaceWith);

            // Write modified file content back to file
            using (StreamWriter writer = new StreamWriter(file))
            {
                writer.Write(fileContent);
            }
        }

        /// <summary>
        /// Replaces all occurences of the old project name in the AssemblyInfo.cs with the new
        /// project name.
        /// </summary>
        protected virtual void ReplaceOccurencesInAssemblyInfo()
        {
            string propertiesDirectory = string.Format("{0}{1}{2}", this.NewProjectDirectoryPath, "\\", Constants.PropertiesDirectory);
            List<string> files = Directory.GetFiles(propertiesDirectory, Constants.AssemblyInfo).ToList();
            if (files.Count == 1)
            {
                try
                {
                    this.Replace(files[0], this.OldProjectName, this.NewProjectName);
                    this.Commands.Add(Constants.ReplaceOccurencesInAssemblyInfo);
                }
                catch (Exception exception)
                {
                    Logger.Log(string.Format("{0} {1}:{2}{3}", DateTime.Now, Constants.ReplaceOccurencesInAssemblyInfo, Environment.NewLine, exception.Message));
                    throw;
                }
            }
        }

        /// <summary>
        /// Replaces recursivly all occurences of the old project name in namespaces in all *cs files 
        /// with the new project name. 
        /// </summary>
        protected virtual void ReplaceOccurencesInNameSpaces()
        {
            // Get all class files in the project folder
            string[] files = Directory.GetFiles(this.NewProjectDirectoryPath, "*.cs", SearchOption.AllDirectories);

            string searchFor = string.Format("{0} {1}", Constants.Namespace, this.OldProjectName);
            string replaceWith = string.Format("{0} {1}", Constants.Namespace, this.NewProjectName);
            foreach (string file in files)
            {
                // Ignore the AssemblyInfo.cs file (that one has no namespace, so no need to replace anything in there)
                if (file.EndsWith(Constants.AssemblyInfo))
                {
                    continue;
                }

                try
                {
                    this.Replace(file, searchFor, replaceWith);
                }
                catch (Exception exception)
                {
                    Logger.Log(string.Format("{0} {1}:{2}{3}", DateTime.Now, Constants.ReplaceOccurencesInNameSpaces, Environment.NewLine, exception.Message));
                    throw;
                }
            }

            this.Commands.Add(Constants.ReplaceOccurencesInNameSpaces);
        }

        /// <summary>
        /// Replaces all occurences of the old project name in the project file (*.csproj) with the new
        /// project name.
        /// </summary>
        protected virtual void ReplaceOccurencesInProjectFile()
        {
            string newProjectFile = string.Format("{0}{1}{2}{3}", this.NewProjectDirectoryPath, "\\", this.NewProjectName, Constants.ProjectFileExtension);
            try
            {
                this.Replace(newProjectFile, this.OldProjectName, this.NewProjectName);
                this.Commands.Add(Constants.ReplaceOccurencesInProjectFile);
            }
            catch (Exception exception)
            {
                Logger.Log(string.Format("{0} {1}:{2}{3}", DateTime.Now, Constants.ReplaceOccurencesInProjectFile, Environment.NewLine, exception.Message));
                throw;
            }
        }

        /// <summary>
        /// Replaces all occurences in the solution file of the old project name with 
        /// the new project name.
        /// </summary>
        protected virtual void ReplaceProjectReferencesInSolutionFile()
        {
            try
            {
                this.Replace(this.SolutionPath, this.OldProjectName, this.NewProjectName);
                this.Commands.Add(Constants.ReplaceProjectReferencesInSolutionFile);
            }
            catch (Exception exception)
            {
                Logger.Log(string.Format("{0} {1}:{2}{3}", DateTime.Now, Constants.ReplaceProjectReferencesInSolutionFile, Environment.NewLine, exception.Message));
                throw;
            }
        }

        /// <summary>
        /// Creates the path to the new project directory, the old project directory and the solution directory
        /// from the absolute path of the solution file as well as the names of the new and old projects.
        /// This is possible because the assumption that the old and new (renamed) projects are physically 
        /// located directly under the solution folder.
        /// </summary>
        /// <param name="solutionFilePath">The absolute path to the solution file</param>
        /// <param name="oldProjectName">The name of the old project</param>
        /// <param name="newProjectName">The name of the new project</param>
        protected virtual void SetDirectories(string solutionFilePath, string oldProjectName, string newProjectName)
        {
            // Get the absolute path to the solution directory from the solution path
            DirectoryInfo solutionDirectory = Directory.GetParent(solutionFilePath);
            if (solutionDirectory != null && !string.IsNullOrEmpty(solutionDirectory.FullName))
            {
                this.SolutionDirectoryPath = solutionDirectory.FullName;
            }
            else
            {
                // There was no directory found (This should actually not be happening)
                string message = string.Format(Constants.NoParentDirectoryFoundError, solutionDirectory);
                Logger.Log(string.Format("{0}:{1}{2}", Constants.SetDirectories, Environment.NewLine, message));
                throw new ArgumentException(message);
            }

            // Find exactly one directory within the solution directory, that has the old project name
            List<string> directories = Directory.GetDirectories(this.SolutionDirectoryPath, oldProjectName, SearchOption.AllDirectories).ToList();
            if (directories.Count == 1)
            {
                // Set the old project directory
                this.OldProjectDirectoryPath = directories[0];

                // Set the new project directory
                this.NewProjectDirectoryPath = string.Format("{0}{1}{2}", Directory.GetParent(this.OldProjectDirectoryPath), "\\", newProjectName);
            }
            else
            {
                // There was no directory found in the solution directory, that contains the old project name.
                string message = string.Format(Constants.NoProjectDirectoryFoundError, oldProjectName);
                Logger.Log(string.Format("{0}:{1}{2}", Constants.SetDirectories, Environment.NewLine, message));
                throw new ArgumentException(message);
            }
        }
    }
}