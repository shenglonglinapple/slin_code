using System;

namespace VSPRBase
{
    using System.IO;

    public class Guard
    {
        public static void FileExists(string file)
        {
            if (!File.Exists(file))
            {
                throw new ArgumentException(file);
            }
        }

        public static void DirectoryExists(string directory)
        {
            if (!Directory.Exists(directory))
            {
                throw new ArgumentException(directory);
            }
        }

        public static void IsNotNullOrEmpty(string value)
        {
            if (string.IsNullOrEmpty(value))
            {
                throw new ArgumentException(value);
            }
        }
    }
}