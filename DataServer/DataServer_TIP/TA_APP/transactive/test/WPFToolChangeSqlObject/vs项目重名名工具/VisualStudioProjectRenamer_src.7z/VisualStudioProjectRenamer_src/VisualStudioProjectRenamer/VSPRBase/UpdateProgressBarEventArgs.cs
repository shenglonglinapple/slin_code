﻿namespace VSPRBase
{
    using System;

    public class UpdateProgressBarEventArgs : EventArgs
    {
        public int Value { get; private set;}

        public UpdateProgressBarEventArgs(int value)
        {
            this.Value = value;
        }
    }
}