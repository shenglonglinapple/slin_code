using System;

namespace VSPRGui
{
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Threading;
    using System.Threading.Tasks;
    using VSPRBase;

    internal class MainFormController
    {
        /// <summary>
        /// Returns a list of all projects, that are located in the solution folder.
        /// </summary>
        /// <param name="solutionpath"></param>
        /// <returns></returns>
        internal List<string> GetSolutionProjects(string solutionpath)
        {
            List<string> projects = new List<string>();
            DirectoryInfo parentDirectory = Directory.GetParent(solutionpath);
            if (parentDirectory != null && !string.IsNullOrEmpty(parentDirectory.FullName))
            {
                List<string> directoryInfos = Directory.GetDirectories(parentDirectory.FullName).ToList();
                foreach (string info in directoryInfos)
                {
                    List<string> directories = info.Split(Path.DirectorySeparatorChar).ToList();
                    string project = directories.Last();

                    // Ommit svn and resharper folders
                    if (!project.EndsWith("svn") && !project.StartsWith("_ReSharper"))
                    {
                        projects.Add(project);
                    }
                }
            }

            return projects;
        }

        /// <summary>
        /// Renames the selected project.
        /// </summary>
        /// <param name="solution"></param>
        /// <param name="oldProjectName"></param>
        /// <param name="newProjectName"></param>
        /// <param name="isUnderVersionControl"></param>
        /// <param name="checkInModifiedFiles"></param>
        /// <param name="form"></param>
        internal void Rename(string solution, string oldProjectName, string newProjectName, bool isUnderVersionControl, bool checkInModifiedFiles = false, MainForm form = null)
        {
            Renamer renamer;

            if (isUnderVersionControl)
            {
                renamer = new SVNRenamer(solution, oldProjectName, newProjectName, checkInModifiedFiles);
            }
            else
            {
                renamer = new StandardRenamer(solution, oldProjectName, newProjectName);
            }

            if (form != null)
            {
                // Attach the method of the form, that will handle the RenameFinished event, to the RenameFinished event handler
                renamer.RenameFinished += form.RenameFinished;
            }

            Task task = new Task(() => renamer.Rename());
            task.Start();
        }

        /// <summary>
        /// Validates the old and new project names.
        /// </summary>
        /// <param name="oldProjectName"></param>
        /// <param name="newProjectName"></param>
        /// <returns></returns>
        internal bool ValidateParameter(string oldProjectName, string newProjectName)
        {
            bool valid = true;

            try
            {
                Guard.IsNotNullOrEmpty(oldProjectName);
                Guard.IsNotNullOrEmpty(newProjectName);

                // Also the old and new project names can not be equal
                if (oldProjectName.Equals(newProjectName))
                {
                    valid = false;
                }

                // Check if the selected solution file is actually a solution file
                
            }
            catch (ArgumentException)
            {
                valid = false;
            }

            return valid;
        }
    }
}