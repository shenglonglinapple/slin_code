namespace VSPRConsole
{
	using VSPRBase;

	internal class Program
	{
		private static void Main()
		{
			const string solution =
				@"C:\Documents and Settings\dkx8d1n\My Documents\Documents\Privat\Projects\vsprojectrename\VisualStudioProjectRenamer\VisualStudioProjectRenamer.sln";
			const string oldProjectName = "TestProject";
			const string newProjectName = "NewTest";

			StandardRenamer renamer = new StandardRenamer(solution, oldProjectName, newProjectName);
			renamer.Rename();
		}
	}
}