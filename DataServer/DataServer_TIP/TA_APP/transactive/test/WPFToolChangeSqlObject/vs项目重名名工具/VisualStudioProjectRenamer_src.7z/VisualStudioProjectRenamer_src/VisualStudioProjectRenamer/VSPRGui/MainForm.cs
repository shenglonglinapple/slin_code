﻿using System;

namespace VSPRGui
{
    using System.Windows.Forms;
    using VSPRBase;

    public partial class MainForm : Form
    {
        private MainFormController Controller { get; set; }
        private String NewProjectName { get; set; }
        private String OldProjectName { get; set; }
        private bool RenameButtonEnabled { get; set; }
        private String Solution { get; set; }
        private String StatusMessage { get; set; }

        public delegate void InvokeDelegate();

        public MainForm()
        {
            this.InitializeComponent();
            this.Controller = new MainFormController();
            this.HideControls();
            this.StatusMessage = "Select solution file";
            this.SetStatusMessage();
        }

        public void RenameFinished(object sender, RenameFinishedEventArgs args)
        {
            this.StatusMessage = args.RenameSuccessfull ? "Project successfully renamed" : "An exception occured during the renaming process, please check the Error.log";
            this.RenameButtonEnabled = args.Finished;
            if (this.InvokeRequired)
            {
                this.Invoke(new InvokeDelegate(this.UpdateProjects));
                this.Invoke(new InvokeDelegate(this.SetStatusMessage));
                this.Invoke(new InvokeDelegate(this.EnableRenameButton));
                this.Invoke(new InvokeDelegate(this.ResetTextBox));
            }
            else
            {
                this.cmbxOldProjectNames.DataSource = this.Controller.GetSolutionProjects(this.Solution);
                this.lblStatus.Text = this.StatusMessage;
                this.btnRename.Enabled = args.Finished;
                this.txbNewProjectName.Text = string.Empty;
            }
        }

        private void ResetTextBox()
        {
            this.txbNewProjectName.Text = string.Empty;
        }

        private void UpdateProjects()
        {
            this.cmbxOldProjectNames.DataSource = this.Controller.GetSolutionProjects(this.Solution);
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            this.Solution = this.ShowFileDialog();

            try
            {
                if (!string.IsNullOrEmpty(this.Solution) && this.Solution.EndsWith(".sln"))
                {
                    Guard.FileExists(this.Solution);

                    this.txbSolutionPath.Text = this.Solution;
                    this.cmbxOldProjectNames.DataSource = this.Controller.GetSolutionProjects(this.Solution);

                    this.ShowControls();
                    this.StatusMessage = "Select a project and enter a new name for it";
                    this.SetStatusMessage();
                }
                else
                {
                    this.ShowErrorMessage("Solution can not be empty, or the selected file is no solution.");
                }
            }
            catch (ArgumentException argumentException)
            {
                this.ShowErrorMessage(argumentException.Message);
            }
        }

        private void btnRename_Click(object sender, EventArgs e)
        {
            this.NewProjectName = this.txbNewProjectName.Text;
            this.OldProjectName = this.cmbxOldProjectNames.SelectedItem.ToString();

            bool isValid = this.Controller.ValidateParameter(this.OldProjectName, this.NewProjectName);
            if (isValid)
            {
                DialogResult dialogResult = this.ConfirmRename();
                if (dialogResult.Equals(DialogResult.OK))
                {
                    // Disable the rename button to prevent a double click on it while renaming is in progress
                    this.btnRename.Enabled = false;
                    this.Cursor = Cursors.WaitCursor;
                    this.lblStatus.Text = @"Renaming project..";

                    try
                    {
                        if (this.cbxIsUnderVersionControl.Checked)
                        {
                            bool checkInChanges = this.cbxCheckInChanges.Checked;
                            this.Controller.Rename(this.Solution, this.OldProjectName, this.NewProjectName, true, checkInChanges, this);
                        }
                        else
                        {
                            this.Controller.Rename(this.Solution, this.OldProjectName, this.NewProjectName, false, false, this);
                        }
                    }
                    catch (Exception exception)
                    {
                        this.ShowErrorMessage(exception.Message);
                        throw;
                    }
                }
            }
            else
            {
                this.ShowErrorMessage("The new name for the project can not be the same as the old one or empty.");
            }
            
        }

        private DialogResult ConfirmRename()
        {
            return MessageBox.Show(string.Format("Do you really want to rename project {0} into {1}?", this.OldProjectName, this.NewProjectName), @"Confirm rename", MessageBoxButtons.OKCancel);
        }

        private void cbxIsUnderVersionControl_CheckedChanged(object sender, EventArgs e)
        {
            if (this.cbxIsUnderVersionControl.Checked)
            {
                this.cbxCheckInChanges.Visible = true;
                this.cbxCheckInChanges.Enabled = true;
                this.cbxCheckInChanges.Checked = false;
            }
            else
            {
                this.cbxCheckInChanges.Visible = false;
                this.cbxCheckInChanges.Enabled = false;
                this.cbxCheckInChanges.Checked = false;
            }
        }

        private void EnableRenameButton()
        {
            this.btnRename.Enabled = this.RenameButtonEnabled;
            this.Cursor = Cursors.Default;
        }

        private void HideControls()
        {
            this.txbSolutionPath.Enabled = false;
            this.lblOldProjectName.Visible = false;
            this.cmbxOldProjectNames.Visible = false;
            this.lblNewProjectName.Visible = false;
            this.cbxCheckInChanges.Visible = false;
            this.txbNewProjectName.Visible = false;
            this.cbxIsUnderVersionControl.Visible = false;
            this.btnRename.Visible = false;
        }

        private void SetStatusMessage()
        {
            this.lblStatus.Text = this.StatusMessage;
        }

        private void ShowControls()
        {
            this.lblOldProjectName.Visible = true;
            this.cmbxOldProjectNames.Visible = true;
            this.lblNewProjectName.Visible = true;
            this.txbNewProjectName.Visible = true;
            this.cbxIsUnderVersionControl.Visible = true;
            this.btnRename.Visible = true;
        }

        private void ShowErrorMessage(string errorMessage)
        {
            string error = string.Format("Error: {0}", errorMessage);
            MessageBox.Show(error, @"Error", MessageBoxButtons.OK);
        }

        private string ShowFileDialog()
        {
            this.openFileDialog.Filter = @"sln files (*.sln)|*.sln|All files (*.*)|*.*";
            this.openFileDialog.FilterIndex = 1;
            this.openFileDialog.RestoreDirectory = true;
            this.openFileDialog.CheckFileExists = true;
            this.openFileDialog.ShowDialog();

            return this.openFileDialog.FileName;
        }
    }
}