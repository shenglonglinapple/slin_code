﻿namespace VSPRExtension
{
	internal class Constants
	{
		internal const string ToolsMenuName = "Tools";
		internal const string Project = "Project";
		internal const string RenameProjectCommand = "RenameProject";
		internal const string RenameProjectFullCommand = "VSPRExtension.Connect.RenameProject";
	}
}