﻿namespace VSPRGui
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.openFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.lblOldProjectName = new System.Windows.Forms.Label();
            this.lblNewProjectName = new System.Windows.Forms.Label();
            this.lblSolutionName = new System.Windows.Forms.Label();
            this.txbNewProjectName = new System.Windows.Forms.TextBox();
            this.btnBrowse = new System.Windows.Forms.Button();
            this.btnRename = new System.Windows.Forms.Button();
            this.txbSolutionPath = new System.Windows.Forms.TextBox();
            this.cmbxOldProjectNames = new System.Windows.Forms.ComboBox();
            this.lblStatus = new System.Windows.Forms.Label();
            this.cbxIsUnderVersionControl = new System.Windows.Forms.CheckBox();
            this.cbxCheckInChanges = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // lblOldProjectName
            // 
            this.lblOldProjectName.AutoSize = true;
            this.lblOldProjectName.Location = new System.Drawing.Point(9, 96);
            this.lblOldProjectName.Name = "lblOldProjectName";
            this.lblOldProjectName.Size = new System.Drawing.Size(143, 13);
            this.lblOldProjectName.TabIndex = 0;
            this.lblOldProjectName.Text = "Select the project to rename:";
            // 
            // lblNewProjectName
            // 
            this.lblNewProjectName.AutoSize = true;
            this.lblNewProjectName.Location = new System.Drawing.Point(9, 152);
            this.lblNewProjectName.Name = "lblNewProjectName";
            this.lblNewProjectName.Size = new System.Drawing.Size(140, 13);
            this.lblNewProjectName.TabIndex = 1;
            this.lblNewProjectName.Text = "Enter the new project name:";
            // 
            // lblSolutionName
            // 
            this.lblSolutionName.AutoSize = true;
            this.lblSolutionName.Location = new System.Drawing.Point(9, 9);
            this.lblSolutionName.Name = "lblSolutionName";
            this.lblSolutionName.Size = new System.Drawing.Size(48, 13);
            this.lblSolutionName.TabIndex = 2;
            this.lblSolutionName.Text = "Solution:";
            // 
            // txbNewProjectName
            // 
            this.txbNewProjectName.Location = new System.Drawing.Point(12, 168);
            this.txbNewProjectName.Name = "txbNewProjectName";
            this.txbNewProjectName.Size = new System.Drawing.Size(368, 20);
            this.txbNewProjectName.TabIndex = 4;
            // 
            // btnBrowse
            // 
            this.btnBrowse.Location = new System.Drawing.Point(302, 51);
            this.btnBrowse.Name = "btnBrowse";
            this.btnBrowse.Size = new System.Drawing.Size(75, 23);
            this.btnBrowse.TabIndex = 5;
            this.btnBrowse.Text = "Browse";
            this.btnBrowse.UseVisualStyleBackColor = true;
            this.btnBrowse.Click += new System.EventHandler(this.btnBrowse_Click);
            // 
            // btnRename
            // 
            this.btnRename.Location = new System.Drawing.Point(302, 290);
            this.btnRename.Name = "btnRename";
            this.btnRename.Size = new System.Drawing.Size(75, 23);
            this.btnRename.TabIndex = 6;
            this.btnRename.Text = "Rename";
            this.btnRename.UseVisualStyleBackColor = true;
            this.btnRename.Click += new System.EventHandler(this.btnRename_Click);
            // 
            // txbSolutionPath
            // 
            this.txbSolutionPath.Location = new System.Drawing.Point(12, 25);
            this.txbSolutionPath.Name = "txbSolutionPath";
            this.txbSolutionPath.Size = new System.Drawing.Size(365, 20);
            this.txbSolutionPath.TabIndex = 7;
            // 
            // cmbxOldProjectNames
            // 
            this.cmbxOldProjectNames.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbxOldProjectNames.FormattingEnabled = true;
            this.cmbxOldProjectNames.Location = new System.Drawing.Point(12, 112);
            this.cmbxOldProjectNames.Name = "cmbxOldProjectNames";
            this.cmbxOldProjectNames.Size = new System.Drawing.Size(365, 21);
            this.cmbxOldProjectNames.TabIndex = 8;
            // 
            // lblStatus
            // 
            this.lblStatus.AutoSize = true;
            this.lblStatus.Location = new System.Drawing.Point(9, 316);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(37, 13);
            this.lblStatus.TabIndex = 9;
            this.lblStatus.Text = "Status";
            // 
            // cbxIsUnderVersionControl
            // 
            this.cbxIsUnderVersionControl.AutoSize = true;
            this.cbxIsUnderVersionControl.Location = new System.Drawing.Point(12, 210);
            this.cbxIsUnderVersionControl.Name = "cbxIsUnderVersionControl";
            this.cbxIsUnderVersionControl.Size = new System.Drawing.Size(175, 17);
            this.cbxIsUnderVersionControl.TabIndex = 10;
            this.cbxIsUnderVersionControl.Text = "Solution under version  control?";
            this.cbxIsUnderVersionControl.UseVisualStyleBackColor = true;
            this.cbxIsUnderVersionControl.CheckedChanged += new System.EventHandler(this.cbxIsUnderVersionControl_CheckedChanged);
            // 
            // cbxCheckInChanges
            // 
            this.cbxCheckInChanges.AutoSize = true;
            this.cbxCheckInChanges.Location = new System.Drawing.Point(12, 233);
            this.cbxCheckInChanges.Name = "cbxCheckInChanges";
            this.cbxCheckInChanges.Size = new System.Drawing.Size(180, 17);
            this.cbxCheckInChanges.TabIndex = 11;
            this.cbxCheckInChanges.Text = "Check in changes after rename?";
            this.cbxCheckInChanges.UseVisualStyleBackColor = true;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(392, 338);
            this.Controls.Add(this.cbxCheckInChanges);
            this.Controls.Add(this.cbxIsUnderVersionControl);
            this.Controls.Add(this.lblStatus);
            this.Controls.Add(this.cmbxOldProjectNames);
            this.Controls.Add(this.txbSolutionPath);
            this.Controls.Add(this.btnRename);
            this.Controls.Add(this.btnBrowse);
            this.Controls.Add(this.txbNewProjectName);
            this.Controls.Add(this.lblSolutionName);
            this.Controls.Add(this.lblNewProjectName);
            this.Controls.Add(this.lblOldProjectName);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "MainForm";
            this.Text = "Visual Studio Project Renamer";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.OpenFileDialog openFileDialog;
        private System.Windows.Forms.Label lblOldProjectName;
        private System.Windows.Forms.Label lblNewProjectName;
        private System.Windows.Forms.Label lblSolutionName;
        private System.Windows.Forms.TextBox txbNewProjectName;
        private System.Windows.Forms.Button btnBrowse;
        private System.Windows.Forms.Button btnRename;
        private System.Windows.Forms.TextBox txbSolutionPath;
        private System.Windows.Forms.ComboBox cmbxOldProjectNames;
        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.CheckBox cbxIsUnderVersionControl;
        private System.Windows.Forms.CheckBox cbxCheckInChanges;
    }
}

