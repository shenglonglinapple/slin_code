﻿namespace VSPRBase
{
    using System;

    public class RenameFinishedEventArgs : EventArgs
    {
        public bool Finished { get; private set; }
        public bool RenameSuccessfull { get; private set; }

        public RenameFinishedEventArgs(bool finished, bool renameSuccessfull)
        {
            this.Finished = finished;
            this.RenameSuccessfull = renameSuccessfull;
        }
    }
}