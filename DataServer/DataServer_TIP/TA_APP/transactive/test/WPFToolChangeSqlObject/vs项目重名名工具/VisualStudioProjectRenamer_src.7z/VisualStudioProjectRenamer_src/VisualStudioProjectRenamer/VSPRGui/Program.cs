﻿using System;

namespace VSPRGui
{
    using System.Windows.Forms;
    using VSPRBase;

    internal static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        private static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            try
            {
                Application.Run(new MainForm());
            }
            catch (Exception exception)
            {
                Logger.Log(string.Format("Exception: {0}", exception.Message));
            }
        }
    }
}