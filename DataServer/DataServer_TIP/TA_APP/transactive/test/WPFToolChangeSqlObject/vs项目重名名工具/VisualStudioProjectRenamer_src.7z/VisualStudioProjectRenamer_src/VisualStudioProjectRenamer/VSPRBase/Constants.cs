namespace VSPRBase
{
	internal class Constants
	{
		// General constants
		internal const string ProjectFileExtension = ".csproj";
		internal const string AssemblyInfo = "AssemblyInfo.cs";
		internal const string Namespace = "namespace";
		internal const string PropertiesDirectory = "Properties";

		// Consants for error message
		internal const string NoParentDirectoryFoundError = "No parent directory found for solution {0}.";
		internal const string NoProjectDirectoryFoundError = "No directory with the name {0} was found in the solution directory.";
	
		// Constants for the logger
		internal static string LogfilePath = @"Error.log";

	    // Constants for method names
		internal const string ReplaceOccurencesInAssemblyInfo = "ReplaceOccurencesInAssemblyInfo";
		internal const string ReplaceOccurencesInNameSpaces = "ReplaceOccurencesInNameSpaces";
		internal const string ReplaceOccurencesInProjectFile = "ReplaceOccurencesInProjectFile";
		internal const string ReplaceProjectReferencesInSolutionFile = "ReplaceProjectReferencesInSolutionFile";
		internal const string SetDirectories = "SetDirectories";
		internal const string Rename = "Rename";
		internal const string RenameProjectFile = "RenameProjectFile";
		internal const string RenameProjectFolder = "RenameProjectFolder";
        internal const string CheckInChanges = "CheckInChanges";
        internal static string UpdateWorkingCopy = "UpdateWorkingCopy";
	}
}