using System;
using System.IO;

namespace VSPRBase
{
	public class Logger
	{
		public static void Log(string message)
		{
			using (StreamWriter streamWriter = new StreamWriter(Constants.LogfilePath, true))
			{
				streamWriter.WriteLine(DateTime.Now);
				streamWriter.WriteLine(message);
				streamWriter.WriteLine();
			}
		}
	}
}