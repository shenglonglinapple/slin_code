using System;

namespace VSPRBase
{
    using SharpSvn;

    public sealed class SVNRenamer : Renamer
    {
        public SVNRenamer(string solutionFilePath, string oldProjectName, string newProjectName, bool comitChanges)
        {
            // Check the parameters for valid values and set directories
            this.CheckParameter(solutionFilePath, oldProjectName, newProjectName);
            this.SetDirectories(solutionFilePath, oldProjectName, newProjectName);

            this.ComitChanges = comitChanges;
            this.SolutionPath = solutionFilePath;
            this.OldProjectName = oldProjectName;
            this.NewProjectName = newProjectName;
        }

        private bool ComitChanges { get; set; }

        public override void Rename()
        {
            bool renameSuccessfull = true;
            try
            {
                if (this.UpdateWorkingCopy())
                {
                    this.ReplaceProjectReferencesInSolutionFile();
                    this.RenameProjectFolder();
                    this.RenameProjectFile();
                    this.ReplaceOccurencesInProjectFile();
                    this.ReplaceOccurencesInAssemblyInfo();
                    this.ReplaceOccurencesInNameSpaces();
                    this.CheckInChanges();
                }
            }
            catch (Exception exception)
            {
                renameSuccessfull = false;
                Logger.Log(string.Format("{0} {1}:{2}{3}", DateTime.Now, Constants.Rename, Environment.NewLine, exception.Message));
                this.RollBack();
            }
            finally
            {
                this.InvokeRenameFinished(new RenameFinishedEventArgs(true, renameSuccessfull));
            }
        }

        /// <summary>
        /// Renames the name of the old project file (*.csproj) to the new project name.
        /// </summary>
        protected override void RenameProjectFile()
        {
            string oldProjectFile = string.Format("{0}{1}{2}{3}", this.NewProjectDirectoryPath, "\\", this.OldProjectName, Constants.ProjectFileExtension);
            string newProjectFile = string.Format("{0}{1}{2}{3}", this.NewProjectDirectoryPath, "\\", this.NewProjectName, Constants.ProjectFileExtension);

            try
            {
                Guard.FileExists(oldProjectFile);
                using (SvnClient svnClient = new SvnClient())
                {
                    svnClient.Move(oldProjectFile, newProjectFile);
                    this.Commands.Add(Constants.RenameProjectFile);
                    this.InvokeUpdateProgressBar(new UpdateProgressBarEventArgs(this.ProgressBarUpdateAmount));
                }
            }
            catch (Exception exception)
            {
                Logger.Log(string.Format("{0} {1}:{2}{3}", DateTime.Now, Constants.RenameProjectFile, Environment.NewLine, exception.Message));
                throw;
            }
        }

        /// <summary>
        /// Renames the name of the old project folder to the new project name.
        /// </summary>
        protected override void RenameProjectFolder()
        {
            try
            {
                using (SvnClient svnClient = new SvnClient())
                {
                    svnClient.Move(this.OldProjectDirectoryPath, this.NewProjectDirectoryPath);
                    this.InvokeUpdateProgressBar(new UpdateProgressBarEventArgs(this.ProgressBarUpdateAmount));
                    this.Commands.Add(Constants.RenameProjectFolder);
                }
            }
            catch (Exception exception)
            {
                Logger.Log(string.Format("{0} {1}:{2}{3}", DateTime.Now, Constants.RenameProjectFolder, Environment.NewLine, exception.Message));
                throw;
            }
        }

        protected override void RollBack()
        {
            // TODO Implement rollback
            foreach (string command in this.Commands)
            {
                Console.WriteLine(command);
            }
        }

        /// <summary>
        /// Checks in the changes to the renamed project.
        /// </summary>
        private void CheckInChanges()
        {
            if (this.ComitChanges)
            {
                try
                {
                    using (SvnClient svnClient = new SvnClient())
                    {
                        SvnCommitArgs svnCommitArgs = new SvnCommitArgs
                        {
                            LogMessage = string.Format("Renamed project {0} into {1}", this.OldProjectName, this.NewProjectName)
                        };

                        SvnCommitResult result;
                        svnClient.Commit(this.SolutionDirectoryPath, svnCommitArgs, out result);
                    }
                }
                catch (Exception exception)
                {
                    Logger.Log(string.Format("{0} {1}:{2}{3}", DateTime.Now, Constants.CheckInChanges, Environment.NewLine, exception.Message));
                    throw;
                }
                finally
                {
                    this.InvokeUpdateProgressBar(new UpdateProgressBarEventArgs(this.ProgressBarUpdateAmount));
                }
            }
        }

        /// <summary>
        /// Updates the working copy.
        /// </summary>
        /// <returns></returns>
        private bool UpdateWorkingCopy()
        {
            bool updateSuccessfull;
            try
            {
                using (SvnClient svnClient = new SvnClient())
                {
                    SvnUpdateResult result;
                    updateSuccessfull = svnClient.Update(this.SolutionDirectoryPath, out result);
                    this.InvokeUpdateProgressBar(new UpdateProgressBarEventArgs(this.ProgressBarUpdateAmount));
                }
            }
            catch (Exception exception)
            {
                Logger.Log(string.Format("{0} {1}:{2}{3}", DateTime.Now, Constants.UpdateWorkingCopy, Environment.NewLine, exception.Message));
                throw;
            }

            return updateSuccessfull;
        }
    }
}