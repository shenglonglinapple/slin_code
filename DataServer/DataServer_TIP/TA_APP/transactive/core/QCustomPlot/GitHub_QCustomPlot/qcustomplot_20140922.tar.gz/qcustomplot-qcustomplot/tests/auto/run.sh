#!/bin/bash

qmake
make 
./autotest

