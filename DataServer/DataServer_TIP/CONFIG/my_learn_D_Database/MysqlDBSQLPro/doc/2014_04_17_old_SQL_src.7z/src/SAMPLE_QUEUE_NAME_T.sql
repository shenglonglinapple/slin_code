DELIMITER $$

DROP TABLE IF EXISTS `SAMPLE_QUEUE_NAME_T` $$

CREATE TABLE  `SAMPLE_QUEUE_NAME_T` (
  `q_name` varchar(128) COLLATE utf8_bin DEFAULT NULL,
  `msg_sid` bigint(30) unsigned NOT NULL,
  `msgid` varchar(64) COLLATE utf8_bin NOT NULL,
  `priority` tinyint(1) unsigned DEFAULT NULL,
  `state` tinyint(1) unsigned NOT NULL,
  `sub_cnt` tinyint(1) unsigned DEFAULT NULL,
  `expiration` datetime DEFAULT NULL,
  `enq_time` datetime NOT NULL,
  `enq_uid` varchar(64) COLLATE utf8_bin DEFAULT NULL,
  `deq_time` datetime DEFAULT NULL,
  `retry_count` int(5) unsigned DEFAULT NULL,
  `sender_msgid` varchar(64) COLLATE utf8_bin DEFAULT NULL,
  `sender_name` varchar(128) COLLATE utf8_bin DEFAULT NULL,
  `sender_addr` varchar(256) COLLATE utf8_bin DEFAULT NULL,
  `user_data` varchar(3000) COLLATE utf8_bin DEFAULT NULL,
  `user_data_1` varchar(3000) COLLATE utf8_bin DEFAULT NULL,
  `user_data_2` varchar(3000) COLLATE utf8_bin DEFAULT NULL,
  `user_data_3` varchar(3000) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`msgid`),
  UNIQUE KEY `idx_qtab_msg_sid` (`msg_sid`),
  UNIQUE KEY `idx_qtab_sender_msgid` (`sender_msgid`),
  KEY `idx_qtab_state` (`state`),
  KEY `idx_qtab_sub_cnt` (`sub_cnt`),
  KEY `idx_qtab_enq_time` (`enq_time`),
  KEY `idx_qtab_deq_time` (`deq_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin $$


DELIMITER ;






