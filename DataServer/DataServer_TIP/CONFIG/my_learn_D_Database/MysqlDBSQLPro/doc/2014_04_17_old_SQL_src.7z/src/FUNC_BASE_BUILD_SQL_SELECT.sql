DELIMITER $$

DROP FUNCTION IF EXISTS `FUNC_BASE_BUILD_SQL_SELECT` $$

CREATE FUNCTION `FUNC_BASE_BUILD_SQL_SELECT`
(
	p_TABLE_NAME VARCHAR(256),
	p_COLUMN_NAME VARCHAR(1024),
	p_WHERE_EXP VARCHAR(8192)
) 
RETURNS VARCHAR(21845)    
BEGIN
	DECLARE str_return_sql  VARCHAR(21845) DEFAULT NULL;
	DECLARE str_key_select  VARCHAR(128) DEFAULT "SELECT";
	DECLARE str_key_from  VARCHAR(128) DEFAULT "FROM";
	DECLARE str_key_where  VARCHAR(128) DEFAULT "WHERE";

	SET str_return_sql = CONCAT(
	' ', str_key_select, ' ',
	' ', p_COLUMN_NAME, ' ',
	' ', str_key_from, ' ',
	' ', p_TABLE_NAME, ' ',
	' ', str_key_where, ' ',
	' ', p_WHERE_EXP, ' '
	);

	RETURN str_return_sql;

END $$

DELIMITER ;

