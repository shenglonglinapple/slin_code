DELIMITER $$

DROP PROCEDURE IF EXISTS `PRC_ENQUEUE_AUDIT_DATA` $$

CREATE PROCEDURE `PRC_ENQUEUE_AUDIT_DATA`(
      IN p_location              VARCHAR(80),
      IN p_message_qualifier     VARCHAR(80),
      IN p_audit_data_Oracle     VARCHAR(4000),
      IN p_audit_data_MySQL      VARCHAR(4000)
)
BEGIN
	DECLARE	str_LOG_LEVEL		VARCHAR(128)	DEFAULT	NULL;
	DECLARE	str_LOG_MSG_FUN		VARCHAR(256)	DEFAULT	NULL;
	DECLARE	str_LOG_MSG_STR0	VARCHAR(8192)	DEFAULT	NULL;
	DECLARE	str_LOG_MSG_STR1	VARCHAR(8192)	DEFAULT	NULL;
	DECLARE	str_LOG_MSG_STR2	VARCHAR(8192)	DEFAULT	NULL;	
	DECLARE	str_DATABASE_NAME	VARCHAR(32)		DEFAULT	NULL;
	DECLARE	str_location		VARCHAR(30)		DEFAULT	NULL;
	DECLARE	v_no_more_row       BOOLEAN DEFAULT FALSE;


	/*
		begin  error process
	*/

	DECLARE CONTINUE HANDLER FOR NOT FOUND
		SET v_no_more_row = TRUE;
		
	DECLARE CONTINUE HANDLER FOR 1062 begin end;
	
	/*
	Add by 2014-04-10 for handle deadlock, the whole transaction will be rollback. For other EXCEPTION, just raise error without rollback.
	*/
	DECLARE EXIT HANDLER FOR SQLSTATE '40001'
	BEGIN
		ROLLBACK;
		/*
		throw exception 40001 again, use resignal
		*/
		resignal;
    END;

	DECLARE EXIT HANDLER FOR SQLSTATE 'XA102'
    BEGIN
		ROLLBACK;
		resignal;
    END;

	/*
	-- Add by 2014-04-10 to record the error for data missing troubleshooting. (Apply successful in local but insert into queue failed)
	*/
	DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
	BEGIN
		ROLLBACK;
		
		START TRANSACTION;
	
		SET str_LOG_LEVEL = CONCAT('ERROR');
		SET str_LOG_MSG_FUN = CONCAT('PRC_ENQUEUE_AUDIT_DATA');
		SET str_LOG_MSG_STR0 = CONCAT('CALL PRC_ENQUEUE_AUDIT_DATA catch SQLEXCEPTION');
		SET str_LOG_MSG_STR1 = CONCAT('p_location=', p_location, ' ', 'p_message_qualifier=', p_message_qualifier, ' ', 'p_audit_data_MySQL=', p_audit_data_MySQL);
		SET str_LOG_MSG_STR2 = CONCAT('p_audit_data_Oracle=', p_audit_data_Oracle);
		PRC_MY_LOG_INSERT(str_LOG_LEVEL, str_LOG_MSG_FUN, str_LOG_MSG_STR0, str_LOG_MSG_STR1, str_LOG_MSG_STR2);
		SET str_LOG_LEVEL = NULL;
		SET str_LOG_MSG_FUN = NULL;
		SET str_LOG_MSG_STR0 = NULL;
		SET str_LOG_MSG_STR1 = NULL;
		SET str_LOG_MSG_STR2 = NULL;
		
		COMMIT;
		
		resignal;
    END;

	/*
	end  error process
	*/


	SET	str_DATABASE_NAME = UPPER(DATABASE());
	IF p_message_qualifier = 'GROUP' 		
	THEN
		SET str_location = concat(' ', ' ');
	ELSEIF p_message_qualifier in ('INSERT', 'UPDATE', 'DELETE') 
	THEN
		SET str_location = p_location;
	ELSE		
		SET str_LOG_LEVEL = CONCAT('WARNING');
		SET str_LOG_MSG_FUN = CONCAT('PRC_ENQUEUE_AUDIT_DATA');
		SET str_LOG_MSG_STR0 = CONCAT('Unknown qualifier');
		SET str_LOG_MSG_STR1 = CONCAT('p_location=', p_location, ' ', 'p_message_qualifier=', p_message_qualifier, ' ', 'p_audit_data_MySQL=', p_audit_data_MySQL);
		SET str_LOG_MSG_STR2 = CONCAT('p_audit_data_Oracle=', p_audit_data_Oracle);
		PRC_MY_LOG_INSERT(str_LOG_LEVEL, str_LOG_MSG_FUN, str_LOG_MSG_STR0, str_LOG_MSG_STR1, str_LOG_MSG_STR2);
		SET str_LOG_LEVEL = NULL;
		SET str_LOG_MSG_FUN = NULL;
		SET str_LOG_MSG_STR0 = NULL;
		SET str_LOG_MSG_STR1 = NULL;
		SET str_LOG_MSG_STR2 = NULL;
	END IF;


END $$

DELIMITER ;

