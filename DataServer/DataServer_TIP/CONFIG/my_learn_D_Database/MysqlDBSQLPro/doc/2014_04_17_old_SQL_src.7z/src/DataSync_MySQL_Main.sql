set autocommit=off;

-- source MY_LOG.sql
-- source ADM_SEQUENCE.sql
-- source CREATE_QUEUE.sql
-- source CREATE_TYPE_AS_OBJECT.sql
-- source FUNC_SEQ_GET_NEXT_NUMBER.sql
-- source PRC_ENQUEUE_AUDIT_DATA.sql
-- source PRC_DBMS_AQADM_CREATE_QUEUE.sql

call PRC_DBMS_AQADM_CREATE_QUEUE("AUDIT_DATA_QUEUE", "AUDIT_DATA_QUEUE_T", "SYS.DBMS_AQADM.NORMAL_QUEUE");

commit;



show procedure status;
show create procedure sp_name;

/*varchar max*/
select 65535

/*varchar utf8 max*/
select 65535 / 3
select 21845

/* 2 ~ N*/
select 2
select 4
select 8
select 16
select 64
select 128
select 256
select 512
select 1024

select 2048
select 4096
select 8192
select 16384


select 32768
select 65536