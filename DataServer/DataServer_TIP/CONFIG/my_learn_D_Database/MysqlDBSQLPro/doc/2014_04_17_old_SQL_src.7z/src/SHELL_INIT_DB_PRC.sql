/**/
DELIMITER $$

DROP PROCEDURE IF EXISTS `PRC_MY_LOG_INSERT` $$

CREATE PROCEDURE `PRC_MY_LOG_INSERT`(
	  IN p_LOG_LEVEL VARCHAR(128),
	  IN p_LOG_MSG_FUN VARCHAR(256),
	  IN p_LOG_MSG_STR0 VARCHAR(8192),
	  IN p_LOG_MSG_STR1 VARCHAR(8192),
	  IN p_LOG_MSG_STR2 VARCHAR(8192)
)
BEGIN
	DECLARE	str_MY_LOG_SEQ	VARCHAR(30)	DEFAULT	'MY_LOG_SEQ';
	DECLARE	str_DATABASE_NAME	VARCHAR(30)	DEFAULT	NULL;
	DECLARE	str_location	VARCHAR(30)	DEFAULT	NULL;
	DECLARE str_TABLE_NAME VARCHAR(256)	DEFAULT	"MY_LOG";
	DECLARE str_COLUMN_NAME VARCHAR(1024)	DEFAULT	"LOG_PKEY, LOG_TIMESTAMP, LOG_LEVEL, LOG_MSG_FUN, LOG_MSG_STR0, LOG_MSG_STR1, LOG_MSG_STR2";
	DECLARE str_COLUMN_VALUE VARCHAR(16384)	DEFAULT	NULL;
	DECLARE str_SQL_INSERT VARCHAR(21845)	DEFAULT	NULL;
	
	SET str_COLUMN_VALUE = CONCAT(
	FUNC_SEQ_GET_NEXT_NUMBER(str_MY_LOG_SEQ), ',',
	'''', now(), '''', ',',
	'''', p_LOG_LEVEL, '''', ',',
	'''', p_LOG_MSG_FUN, '''', ',',
	'''', p_LOG_MSG_STR0, '''', ',',
	'''', p_LOG_MSG_STR1, '''', ',',
	'''', p_LOG_MSG_STR2, '''', ',',
	);
	
	SET str_SQL_INSERT = FUNC_BASE_BUILD_SQL_INSERT(str_TABLE_NAME, str_COLUMN_NAME, str_COLUMN_VALUE);
	SET @G_SQL=NULL;
	SET @G_SQL=str_SQL_INSERT;
	
	-- insert data to CREATE_QUEUE 
	PREPARE stmt_INSERT_INTO_MY_LOG FROM @G_SQL;
	EXECUTE stmt_INSERT_INTO_MY_LOG;
	DEALLOCATE PREPARE stmt_INSERT_INTO_MY_LOG;
	set @G_SQL = null;

END $$

DELIMITER ;

/**/














/**/

DELIMITER $$

DROP PROCEDURE IF EXISTS `PRC_ENQUEUE_AUDIT_DATA` $$

CREATE PROCEDURE `PRC_ENQUEUE_AUDIT_DATA`(
      IN p_location              VARCHAR(80),
      IN p_message_qualifier     VARCHAR(80),
      IN p_audit_data_Oracle     VARCHAR(4000),
      IN p_audit_data_MySQL      VARCHAR(4000)
)
BEGIN
	DECLARE	str_LOG_LEVEL		VARCHAR(128)	DEFAULT	NULL;
	DECLARE	str_LOG_MSG_FUN		VARCHAR(256)	DEFAULT	NULL;
	DECLARE	str_LOG_MSG_STR0	VARCHAR(8192)	DEFAULT	NULL;
	DECLARE	str_LOG_MSG_STR1	VARCHAR(8192)	DEFAULT	NULL;
	DECLARE	str_LOG_MSG_STR2	VARCHAR(8192)	DEFAULT	NULL;	
	DECLARE	str_DATABASE_NAME	VARCHAR(32)		DEFAULT	NULL;
	DECLARE	str_location		VARCHAR(30)		DEFAULT	NULL;
	DECLARE	v_no_more_row       BOOLEAN DEFAULT FALSE;


	/*
		begin  error process
	*/

	DECLARE CONTINUE HANDLER FOR NOT FOUND
		SET v_no_more_row = TRUE;
		
	DECLARE CONTINUE HANDLER FOR 1062 begin end;
	
	/*
	Add by 2014-04-10 for handle deadlock, the whole transaction will be rollback. For other EXCEPTION, just raise error without rollback.
	*/
	DECLARE EXIT HANDLER FOR SQLSTATE '40001'
	BEGIN
		ROLLBACK;
		/*
		throw exception 40001 again, use resignal
		*/
		resignal;
    END;

	DECLARE EXIT HANDLER FOR SQLSTATE 'XA102'
    BEGIN
		ROLLBACK;
		resignal;
    END;

	/*
	-- Add by 2014-04-10 to record the error for data missing troubleshooting. (Apply successful in local but insert into queue failed)
	*/
	DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
	BEGIN
		ROLLBACK;
		
		START TRANSACTION;
	
		SET str_LOG_LEVEL = CONCAT('ERROR');
		SET str_LOG_MSG_FUN = CONCAT('PRC_ENQUEUE_AUDIT_DATA');
		SET str_LOG_MSG_STR0 = CONCAT('CALL PRC_ENQUEUE_AUDIT_DATA catch SQLEXCEPTION');
		SET str_LOG_MSG_STR1 = CONCAT('p_location=', p_location, ' ', 'p_message_qualifier=', p_message_qualifier, ' ', 'p_audit_data_MySQL=', p_audit_data_MySQL);
		SET str_LOG_MSG_STR2 = CONCAT('p_audit_data_Oracle=', p_audit_data_Oracle);
		PRC_MY_LOG_INSERT(str_LOG_LEVEL, str_LOG_MSG_FUN, str_LOG_MSG_STR0, str_LOG_MSG_STR1, str_LOG_MSG_STR2);
		SET str_LOG_LEVEL = NULL;
		SET str_LOG_MSG_FUN = NULL;
		SET str_LOG_MSG_STR0 = NULL;
		SET str_LOG_MSG_STR1 = NULL;
		SET str_LOG_MSG_STR2 = NULL;
		
		COMMIT;
		
		resignal;
    END;

	/*
	end  error process
	*/


	SET	str_DATABASE_NAME = UPPER(DATABASE());
	IF p_message_qualifier = 'GROUP' 		
	THEN
		SET str_location = concat(' ', ' ');
	ELSEIF p_message_qualifier in ('INSERT', 'UPDATE', 'DELETE') 
	THEN
		SET str_location = p_location;
	ELSE		
		SET str_LOG_LEVEL = CONCAT('WARNING');
		SET str_LOG_MSG_FUN = CONCAT('PRC_ENQUEUE_AUDIT_DATA');
		SET str_LOG_MSG_STR0 = CONCAT('Unknown qualifier');
		SET str_LOG_MSG_STR1 = CONCAT('p_location=', p_location, ' ', 'p_message_qualifier=', p_message_qualifier, ' ', 'p_audit_data_MySQL=', p_audit_data_MySQL);
		SET str_LOG_MSG_STR2 = CONCAT('p_audit_data_Oracle=', p_audit_data_Oracle);
		PRC_MY_LOG_INSERT(str_LOG_LEVEL, str_LOG_MSG_FUN, str_LOG_MSG_STR0, str_LOG_MSG_STR1, str_LOG_MSG_STR2);
		SET str_LOG_LEVEL = NULL;
		SET str_LOG_MSG_FUN = NULL;
		SET str_LOG_MSG_STR0 = NULL;
		SET str_LOG_MSG_STR1 = NULL;
		SET str_LOG_MSG_STR2 = NULL;
	END IF;


END $$

DELIMITER ;

/**/






/**/
DELIMITER $$

DROP PROCEDURE IF EXISTS `PRC_DBMS_AQADM_CREATE_QUEUE` $$

CREATE PROCEDURE `PRC_DBMS_AQADM_CREATE_QUEUE`(
	IN p_QUEUE_NAME      VARCHAR(128),
	IN p_QUEUE_TABLE      VARCHAR(128),
	IN p_QUEUE_TYPE      VARCHAR(256)
)
	/*
	p_QUEUE_NAME='AUDIT_DATA_QUEUE',
	p_QUEUE_TABLE='AUDIT_DATA_QUEUE_T',
	p_QUEUE_TYPE='SYS.DBMS_AQADM.NORMAL_QUEUE',
	str_OBJECT_NAME='AUDIT_DATA_QUEUE_PAYLOAD_TYPE',
	*/
BEGIN
	DECLARE str_QUEUE_NAME    VARCHAR(128) DEFAULT NULL;
	DECLARE str_QUEUE_TABLE    VARCHAR(128) DEFAULT NULL;
	DECLARE str_QUEUE_TYPE    VARCHAR(256) DEFAULT NULL;
	DECLARE str_OBJECT_NAME    VARCHAR(256) DEFAULT NULL;
	DECLARE str_SQL_CREATE_QUEUE_TABLE_T    VARCHAR(8192) DEFAULT NULL;
	

	SET str_QUEUE_NAME = p_QUEUE_NAME;
	SET str_QUEUE_TABLE = p_QUEUE_TABLE;
	SET str_QUEUE_TYPE = p_QUEUE_TYPE;
	SET str_OBJECT_NAME = CONCAT('AUDIT_DATA_QUEUE_PAYLOAD_TYPE');
	
	SET str_SQL_CREATE_QUEUE_TABLE_T = CONCAT('CREATE TABLE ', p_QUEUE_TABLE, 'LIKE SAMPLE_QUEUE_NAME_T');-- CONCAT();



	set @str_STMT_SQL = null;
	SET @str_STMT_SQL = CONCAT('INSERT INTO CREATE_QUEUE(',
	'QUEUE_NAME,',
	'QUEUE_TABLE,',
	'QUEUE_TYPE,',
	'OBJECT_NAME,',
	'SQL_CREATE_QUEUE_TABLE_T)',
	'VALUES(',
	'''',str_QUEUE_NAME, '''',',',
	'''',str_QUEUE_TABLE, '''',',',
	'''',str_QUEUE_TYPE, '''',',',
	'''',str_OBJECT_NAME, '''',',',
	'''',str_SQL_CREATE_QUEUE_TABLE_T,'''',')'
	);
	
	-- insert data to CREATE_QUEUE 
	PREPARE stmt_INSERT_INTO_CREATE_QUEUE FROM @str_STMT_SQL;
	EXECUTE stmt_INSERT_INTO_CREATE_QUEUE;
	DEALLOCATE PREPARE stmt_INSERT_INTO_CREATE_QUEUE;
	set @str_STMT_SQL = null;
	
	-- exec sql to create table p_QUEUE_TABLE='AUDIT_DATA_QUEUE_T',
	set @str_STMT_SQL = null;			
	set @str_STMT_SQL = str_SQL_CREATE_QUEUE_TABLE_T;
	PREPARE stmt_CREATE_QUEUE_TABLE_T FROM @str_STMT_SQL;
	EXECUTE stmt_CREATE_QUEUE_TABLE_T;
	DEALLOCATE PREPARE stmt_CREATE_QUEUE_TABLE_T;
	set @str_STMT_SQL = null;

END $$

DELIMITER ;

/**/









/**/

/**/














