DELIMITER $$

DROP FUNCTION IF EXISTS `FUNC_BASE_BUILD_SQL_UPDATE` $$

CREATE FUNCTION `FUNC_BASE_BUILD_SQL_UPDATE`
(
	p_TABLE_NAME VARCHAR(256),
	p_UPDATE_EXP VARCHAR(8192),
	p_WHERE_EXP VARCHAR(8192)
) 
RETURNS VARCHAR(21845)    
BEGIN
	DECLARE str_return_sql  VARCHAR(21845) DEFAULT NULL;
	DECLARE str_key_update  VARCHAR(128) DEFAULT "UPDATE";
	DECLARE str_key_set  VARCHAR(128) DEFAULT "SET";
	DECLARE str_key_where  VARCHAR(128) DEFAULT "WHERE";

	SET str_return_sql = CONCAT(
	' ', str_key_update, ' ',
	' ', p_TABLE_NAME, ' ',
	' ', str_key_set, ' ',
	' ', p_UPDATE_EXP, ' ',
	' ', str_key_where, ' ',
	' ', p_WHERE_EXP, ' '
	);

	RETURN str_return_sql;

END $$

DELIMITER ;

