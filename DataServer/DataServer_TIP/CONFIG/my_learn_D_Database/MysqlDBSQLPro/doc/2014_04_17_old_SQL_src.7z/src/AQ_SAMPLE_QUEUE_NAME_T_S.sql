DELIMITER $$

DROP TABLE IF EXISTS `AQ_SAMPLE_QUEUE_NAME_T_S` $$

CREATE TABLE  `AQ_SAMPLE_QUEUE_NAME_T_S` (
  `sub_id` int(5) unsigned NOT NULL,
  `q_name` varchar(128) COLLATE utf8_bin NOT NULL,
  `sub_name` varchar(128) COLLATE utf8_bin DEFAULT NULL,
  `sub_address` varchar(256) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`sub_id`),
  UNIQUE KEY `idx_sub_address` (`sub_address`),
  KEY `idx_sub_name` (`sub_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin $$


DELIMITER ;






