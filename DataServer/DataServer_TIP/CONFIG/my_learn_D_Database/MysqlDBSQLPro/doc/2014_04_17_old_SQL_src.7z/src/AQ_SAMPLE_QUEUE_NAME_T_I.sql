DELIMITER $$

DROP TABLE IF EXISTS `AQ_SAMPLE_QUEUE_NAME_T_I` $$

CREATE TABLE  `AQ_SAMPLE_QUEUE_NAME_T_I` (
  `sub_id` int(5) unsigned NOT NULL,
  `sub_name` varchar(128) COLLATE utf8_bin NOT NULL,
  `msg_sid` bigint(20) unsigned NOT NULL,
  `msgid` varchar(64) COLLATE utf8_bin NOT NULL,
  `state` tinyint(3) unsigned NOT NULL,
  KEY `idx_sub_id` (`sub_id`),
  KEY `idx_sub_name` (`sub_name`),
  KEY `idx_msg_sid` (`msg_sid`),
  KEY `idx_enq_msgid` (`msgid`),
  KEY `idx_enq_state` (`state`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin $$

DELIMITER ;






