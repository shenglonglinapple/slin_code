
/**/
DELIMITER $$

DROP TABLE IF EXISTS  `ADM_SEQUENCE` $$

CREATE TABLE `ADM_SEQUENCE` (
  `SEQ_PKEY` INT(11) NOT NULL,
  `SEQ_NAME` VARCHAR(128) COLLATE utf8_bin NOT NULL,
  `INIT_NUMBER` BIGINT(20) NOT NULL,
  `LAST_NUMBER` DECIMAL(30,0) NOT NULL,
  `MAX_NUMBER` DECIMAL(30,0) NOT NULL,
  `INCREMENT_BY` INT(11) NOT NULL,
  `CYCLE_FLAG` VARCHAR(1) COLLATE utf8_bin NOT NULL,
  
  PRIMARY KEY (`SEQ_PKEY`),
  UNIQUE KEY `idx_adm_seq_name` (`SEQ_NAME`) USING BTREE
  
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin $$

DELIMITER ;
/**/



/**/
DELIMITER $$

DROP TABLE IF EXISTS  `MY_LOG` $$


CREATE TABLE `MY_LOG` (
  `LOG_PKEY` DECIMAL(30,0) NOT NULL,
  `LOG_TIMESTAMP` DATETIME NOT NULL,
  `LOG_LEVEL` VARCHAR(128),
  `LOG_MSG_FUN` VARCHAR(256),
  `LOG_MSG_STR0` VARCHAR(8192),
  `LOG_MSG_STR1` VARCHAR(8192),
  `LOG_MSG_STR2` VARCHAR(8192),
  
  PRIMARY KEY (`LOG_PKEY`),
  KEY `ERRORLOG_TIMESTAMP_IDX` (`LOG_TIMESTAMP`)
  
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin $$

DELIMITER ;
/**/



/**/
DELIMITER $$

DROP TABLE IF EXISTS  `CREATE_TYPE_AS_OBJECT` $$

CREATE TABLE `CREATE_TYPE_AS_OBJECT` (
  `OBJECT_PKEY` INT NOT NULL AUTO_INCREMENT,
  `OBJECT_NAME` VARCHAR(256) COLLATE utf8_bin NOT NULL,
  `QUEUE_NAME` VARCHAR(128) COLLATE utf8_bin NOT NULL,
  `OBJECT_MSG` VARCHAR(1024) COLLATE utf8_bin NOT NULL,
  
  PRIMARY KEY (`OBJECT_PKEY`),
  UNIQUE KEY `idx_create_object_key` (`OBJECT_PKEY`) USING BTREE
  
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin $$


DELIMITER ;
/**/


/**/
DELIMITER $$

DROP TABLE IF EXISTS  `CREATE_QUEUE_RECORD` $$

CREATE TABLE `CREATE_QUEUE_RECORD` (
  `QUEUE_PKEY` INT NOT NULL AUTO_INCREMENT,
  `QUEUE_NAME` VARCHAR(128) COLLATE utf8_bin NOT NULL,
  `QUEUE_TABLE` VARCHAR(128) COLLATE utf8_bin NOT NULL,
  `QUEUE_TYPE` VARCHAR(256) COLLATE utf8_bin NOT NULL,
  `OBJECT_NAME` VARCHAR(256) COLLATE utf8_bin NOT NULL,
  `SQL_CREATE_QUEUE_TABLE_T` VARCHAR(8192) COLLATE utf8_bin NOT NULL,
  
  PRIMARY KEY (`QUEUE_PKEY`),
  UNIQUE KEY `idx_create_queue_key` (`QUEUE_PKEY`) USING BTREE
  
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin $$

DELIMITER ;
/**/




/**/
DELIMITER $$

DROP TABLE IF EXISTS `SAMPLE_QUEUE_NAME_T` $$

CREATE TABLE  `SAMPLE_QUEUE_NAME_T` (
  `q_name` varchar(128) COLLATE utf8_bin DEFAULT NULL,
  `msg_sid` bigint(30) unsigned NOT NULL,
  `msgid` varchar(64) COLLATE utf8_bin NOT NULL,
  `priority` tinyint(1) unsigned DEFAULT NULL,
  `state` tinyint(1) unsigned NOT NULL,
  `sub_cnt` tinyint(1) unsigned DEFAULT NULL,
  `expiration` datetime DEFAULT NULL,
  `enq_time` datetime NOT NULL,
  `enq_uid` varchar(64) COLLATE utf8_bin DEFAULT NULL,
  `deq_time` datetime DEFAULT NULL,
  `retry_count` int(5) unsigned DEFAULT NULL,
  `sender_msgid` varchar(64) COLLATE utf8_bin DEFAULT NULL,
  `sender_name` varchar(128) COLLATE utf8_bin DEFAULT NULL,
  `sender_addr` varchar(256) COLLATE utf8_bin DEFAULT NULL,
  `user_data` varchar(3000) COLLATE utf8_bin DEFAULT NULL,
  `user_data_1` varchar(3000) COLLATE utf8_bin DEFAULT NULL,
  `user_data_2` varchar(3000) COLLATE utf8_bin DEFAULT NULL,
  `user_data_3` varchar(3000) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`msgid`),
  UNIQUE KEY `idx_qtab_msg_sid` (`msg_sid`),
  UNIQUE KEY `idx_qtab_sender_msgid` (`sender_msgid`),
  KEY `idx_qtab_state` (`state`),
  KEY `idx_qtab_sub_cnt` (`sub_cnt`),
  KEY `idx_qtab_enq_time` (`enq_time`),
  KEY `idx_qtab_deq_time` (`deq_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin $$


DELIMITER ;
/**/



/**/
DELIMITER $$

DROP TABLE IF EXISTS `AQ_SAMPLE_QUEUE_NAME_T_I` $$

CREATE TABLE  `AQ_SAMPLE_QUEUE_NAME_T_I` (
  `sub_id` int(5) unsigned NOT NULL,
  `sub_name` varchar(128) COLLATE utf8_bin NOT NULL,
  `msg_sid` bigint(20) unsigned NOT NULL,
  `msgid` varchar(64) COLLATE utf8_bin NOT NULL,
  `state` tinyint(3) unsigned NOT NULL,
  KEY `idx_sub_id` (`sub_id`),
  KEY `idx_sub_name` (`sub_name`),
  KEY `idx_msg_sid` (`msg_sid`),
  KEY `idx_enq_msgid` (`msgid`),
  KEY `idx_enq_state` (`state`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin $$

DELIMITER ;
/**/



/**/
DELIMITER $$

DROP TABLE IF EXISTS `AQ_SAMPLE_QUEUE_NAME_T_S` $$

CREATE TABLE  `AQ_SAMPLE_QUEUE_NAME_T_S` (
  `sub_id` int(5) unsigned NOT NULL,
  `q_name` varchar(128) COLLATE utf8_bin NOT NULL,
  `sub_name` varchar(128) COLLATE utf8_bin DEFAULT NULL,
  `sub_address` varchar(256) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`sub_id`),
  UNIQUE KEY `idx_sub_address` (`sub_address`),
  KEY `idx_sub_name` (`sub_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin $$


DELIMITER ;
/**/




















