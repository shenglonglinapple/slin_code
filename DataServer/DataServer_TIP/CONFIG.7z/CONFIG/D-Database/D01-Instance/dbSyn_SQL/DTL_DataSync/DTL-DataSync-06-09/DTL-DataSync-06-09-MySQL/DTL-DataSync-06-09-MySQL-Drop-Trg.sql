drop trigger if exists alarm_printevent_trg;
drop trigger if exists evcom_printevent_trg;