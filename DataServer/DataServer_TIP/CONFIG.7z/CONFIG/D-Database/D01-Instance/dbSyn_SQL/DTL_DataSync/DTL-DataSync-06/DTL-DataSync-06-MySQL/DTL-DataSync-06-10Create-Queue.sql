call prc_create_queue('audit_data_queue',0,0,0);
call prc_create_queue('mms_data_queue',0,0,0);