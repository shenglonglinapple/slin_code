alter system set job_queue_processes = 10 scope = both;

commit;
quit;