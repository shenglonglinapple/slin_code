alter system set job_queue_processes = 0 scope = both;

commit;
quit;