#include "ItemBoxScene.h"
#include "CommonData.h"
#include "RectItemInBox.h"


//#include "BoostLogger.h"
//USING_BOOST_LOG;


//QT_BEGIN_NAMESPACE
////QT_END_NAMESPACE

//////////////////////////////////////////////////////////////////////////


CItemBoxScene::CItemBoxScene( QObject *parent /*= 0*/ )
:QGraphicsScene(parent)
{

	//rectItem = QRectF(DEF_VALUE_InfomationRectItem_X, DEF_VALUE_InfomationRectItem_Y, 
	//	DEF_VALUE_InfomationRectItem_Width, DEF_VALUE_InfomationRectItem_Height);

}

CItemBoxScene::~CItemBoxScene()
{

}




