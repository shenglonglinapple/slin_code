#ifndef __CLASS_SAMPLE_CLASS_IMP_HH__
#define __CLASS_SAMPLE_CLASS_IMP_HH__



class CSampleClassImp
{
public:
	CSampleClassImp();
	virtual ~CSampleClassImp();
public:
	int testFun(int nParamOne);

private:
	int m_nTotal;
};


#endif//__CLASS_SAMPLE_CLASS_IMP_HH__


