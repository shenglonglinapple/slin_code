#ifndef  __DEF__THREADS_COMMON_DEF_H_
#define  __DEF__THREADS_COMMON_DEF_H_

#include "core/utilities/src/UtilitiesCommonDef.h"

NS_BEGIN(TA_Base_Core) 


NS_END(TA_Base_Core)

#endif  // __DEF__THREADS_COMMON_DEF_H_











