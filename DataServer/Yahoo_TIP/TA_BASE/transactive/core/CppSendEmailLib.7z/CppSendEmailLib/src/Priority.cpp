#include "core/CppSendEmailLib/src/Priority.h"

#include <iostream>
#include <time.h>
#include <stdlib.h>

//
NS_BEGIN(TA_Base_Core)

// constants defination
/////////////////////////////////////


const std::string Priority::important = "1";
const std::string Priority::normal    = "3";
const std::string Priority::trivial   = "5";


NS_END(TA_Base_Core)

