#ifndef __CLASS_WINSOCKHELPER_H__
#define __CLASS_WINSOCKHELPER_H__

#include "core/utilities/src/UtilitiesCommonDef.h"




//
NS_BEGIN(TA_Base_Core)

class WinSockHelper
{
public:
	WinSockHelper();

	virtual ~WinSockHelper();
};

NS_END(TA_Base_Core)


#endif // __CLASS_WINSOCKHELPER_H__