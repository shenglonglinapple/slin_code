#ifndef __CLASS_MY_CPP_SEND_EMAIL_TEST__HH__
#define __CLASS_MY_CPP_SEND_EMAIL_TEST__HH__

#include "core/utilities/src/UtilitiesCommonData.h"

NS_BEGIN(TA_Base_Test) 



class CMyCppSendMailTest 
{
public:
	CMyCppSendMailTest(void);
	virtual ~CMyCppSendMailTest(void);
public:
	void test_SendOneEmail();
};

NS_END(TA_Base_Test) 


#endif //__CLASS_MY_CPP_SEND_EMAIL_TEST__HH__


