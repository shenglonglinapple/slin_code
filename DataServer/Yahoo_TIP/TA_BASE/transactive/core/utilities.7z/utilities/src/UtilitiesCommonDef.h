#ifndef  __DEF__UTILITIES_COMMON_DEF_H_
#define  __DEF__UTILITIES_COMMON_DEF_H_

#include "core/utilities/src/UtilitiesSysTypes.h"

//////////////////////////////////////////////////////////////////////////
///#define
//////////////////////////////////////////////////////////////////////////

//---------------------------------------------------------------
// easy usage of the namespace identifier
#define  NS_BEGIN(name)			namespace name {
#define  NS_END(name)			};
//---------------------------------------------------------------



#endif  // __DEF__UTILITIES_COMMON_DEF_H_











