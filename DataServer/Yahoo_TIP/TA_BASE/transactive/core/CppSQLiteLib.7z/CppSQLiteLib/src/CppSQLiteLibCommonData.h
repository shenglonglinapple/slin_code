#ifndef  __DEF__CPP_SQLITE_LIB_COMMON_DATA_H_
#define  __DEF__CPP_SQLITE_LIB_COMMON_DATA_H_

#include "core/utilities/src/UtilitiesCommonData.h"
#include "core/CppSQLiteLib/src/CppSQLiteLibCommonDef.h"


//////////////////////////////////////////////////////////////////////////
//include

#include "sqlite3.h"
#include <stdio.h>
#include <string.h>
#include <cstdlib>



NS_BEGIN(TA_Base_Core)



NS_END(TA_Base_Core)

#endif  // __DEF__CPP_SQLITE_LIB_COMMON_DATA_H_








