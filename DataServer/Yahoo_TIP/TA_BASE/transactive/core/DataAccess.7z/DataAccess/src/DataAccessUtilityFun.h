#ifndef __CLASS_DATA_ACCESS_UTILITY_FUN_H__
#define __CLASS_DATA_ACCESS_UTILITY_FUN_H__ 


#include "core/DataAccess/src/DataAccessCommonData.h"



NS_BEGIN(TA_Base_Core)


class CDataAccessUtilityFun
{
public:
	CDataAccessUtilityFun(void);	
	~CDataAccessUtilityFun(void);

};


NS_END(TA_Base_Core)


#endif // __CLASS_DATA_ACCESS_UTILITY_FUN_H__









