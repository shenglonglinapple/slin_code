#include "DataAccessUtilityFun.h"


NS_BEGIN(TA_Base_Core)


CDataAccessUtilityFun::CDataAccessUtilityFun( void )
{

}

CDataAccessUtilityFun::~CDataAccessUtilityFun( void )
{

}





NS_END(TA_Base_Core)
















